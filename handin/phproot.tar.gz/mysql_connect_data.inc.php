<?php
	$host = "puccini.cs.lth.se";
	$userName = "db104";
	$password = "hej123";
	$database = "db104";
?>
